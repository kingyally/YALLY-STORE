import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SONICPESA_BASE_URL = "https://api.sonicpesa.com/api/v1";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const SONICPESA_API_KEY = Deno.env.get("SONICPESA_API_KEY");
  if (!SONICPESA_API_KEY) {
    return new Response(
      JSON.stringify({ error: "SONICPESA_API_KEY not configured" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const { action, ...params } = await req.json();

    if (action === "create_order") {
      const { buyer_name, buyer_email, buyer_phone, amount, user_id, tipster_id } = params;

      if (!buyer_phone || !amount || !user_id || !tipster_id) {
        return new Response(
          JSON.stringify({ error: "Missing required fields: buyer_phone, amount, user_id, tipster_id" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Normalize phone to 255 format
      let phone = buyer_phone.replace(/[\s\-()]/g, "");
      if (phone.startsWith("0")) phone = "255" + phone.slice(1);
      if (phone.startsWith("+")) phone = phone.slice(1);

      const orderPayload = {
        buyer_email: buyer_email || "",
        buyer_name: buyer_name || "Customer",
        buyer_phone: phone,
        amount: Number(amount),
        currency: "TZS",
      };

      console.log("Creating SonicPesa order:", JSON.stringify(orderPayload));

      const response = await fetch(`${SONICPESA_BASE_URL}/payment/create_order`, {
        method: "POST",
        headers: {
          "X-API-KEY": SONICPESA_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderPayload),
      });

      const data = await response.json();
      console.log("SonicPesa create_order response:", JSON.stringify(data));

      if (!response.ok) {
        return new Response(
          JSON.stringify({ error: `SonicPesa error [${response.status}]`, details: data }),
          { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Save pending ticket record
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      // Save pending payment record (will be set to 'approved' once payment confirmed via polling)
      await supabase
        .from("unlocked_tickets")
        .upsert(
          { user_id, tipster_id: Number(tipster_id), status: "pending" },
          { onConflict: "user_id,tipster_id" }
        );

      return new Response(JSON.stringify({ success: true, data: data?.data }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "check_status") {
      const { order_id } = params;

      if (!order_id) {
        return new Response(
          JSON.stringify({ error: "Missing order_id" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const response = await fetch(`${SONICPESA_BASE_URL}/payment/order_status`, {
        method: "POST",
        headers: {
          "X-API-KEY": SONICPESA_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ order_id }),
      });

      const data = await response.json();
      console.log("SonicPesa order_status response:", JSON.stringify(data));

      if (!response.ok) {
        return new Response(
          JSON.stringify({ error: `SonicPesa status check failed [${response.status}]`, details: data }),
          { status: response.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // If payment succeeded, update ticket status
      const paymentStatus = data?.data?.payment_status || data?.data?.status;
      if (paymentStatus === "SUCCESS") {
        const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
        const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const supabase = createClient(supabaseUrl, supabaseKey);

        const { user_id, tipster_id } = params;
        if (user_id && tipster_id) {
          await supabase
            .from("unlocked_tickets")
            .update({ status: "approved" })
            .eq("user_id", user_id)
            .eq("tipster_id", tipster_id);
        }
      }

      return new Response(JSON.stringify({ success: true, data: data?.data, status: paymentStatus }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({ error: "Invalid action. Use 'create_order' or 'check_status'" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("SonicPesa edge function error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
