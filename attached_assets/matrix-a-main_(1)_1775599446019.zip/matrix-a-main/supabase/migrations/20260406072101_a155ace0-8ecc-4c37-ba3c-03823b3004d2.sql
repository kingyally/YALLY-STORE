
-- Tipsters table
CREATE TABLE public.tipsters (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL DEFAULT 'VIP TICKET',
  odds TEXT NOT NULL DEFAULT '10.00',
  company TEXT DEFAULT '',
  avatar TEXT NOT NULL DEFAULT '',
  code TEXT NOT NULL DEFAULT '',
  is_free BOOLEAN NOT NULL DEFAULT false,
  expiry_time INTEGER NOT NULL DEFAULT 12000,
  expiry_date TEXT,
  prices JSONB DEFAULT '[{"name":"Siku 1","p":2000,"discount":0}]',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- History table
CREATE TABLE public.bet_history (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL DEFAULT '',
  date TEXT NOT NULL DEFAULT '',
  result TEXT NOT NULL DEFAULT 'WON',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Packages table
CREATE TABLE public.packages (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL DEFAULT '',
  price INTEGER NOT NULL DEFAULT 0,
  discount INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- App settings table (single row)
CREATE TABLE public.app_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_channel TEXT DEFAULT 'https://t.me/matrixbetting',
  whatsapp_group TEXT DEFAULT 'https://chat.whatsapp.com/matrixvip',
  whatsapp_number TEXT DEFAULT '255765902829',
  support_email TEXT DEFAULT 'support@matrixbet.co.tz',
  payment_number TEXT DEFAULT '0765 902 829',
  payment_methods TEXT[] DEFAULT ARRAY['M-PESA','TIGO PESA','AIRTEL MONEY'],
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.tipsters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bet_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Public read for all
CREATE POLICY "Anyone can read tipsters" ON public.tipsters FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can read history" ON public.bet_history FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can read packages" ON public.packages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can read settings" ON public.app_settings FOR SELECT TO anon, authenticated USING (true);

-- Admin write (open for now since admin check is app-level)
CREATE POLICY "Anyone can insert tipsters" ON public.tipsters FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update tipsters" ON public.tipsters FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete tipsters" ON public.tipsters FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Anyone can insert history" ON public.bet_history FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update history" ON public.bet_history FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete history" ON public.bet_history FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Anyone can insert packages" ON public.packages FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update packages" ON public.packages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Anyone can delete packages" ON public.packages FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "Anyone can insert settings" ON public.app_settings FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can update settings" ON public.app_settings FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Insert default settings row
INSERT INTO public.app_settings (telegram_channel, whatsapp_group, whatsapp_number, support_email, payment_number, payment_methods)
VALUES ('https://t.me/matrixbetting', 'https://chat.whatsapp.com/matrixvip', '255765902829', 'support@matrixbet.co.tz', '0765 902 829', ARRAY['M-PESA','TIGO PESA','AIRTEL MONEY']);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.tipsters;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bet_history;
ALTER PUBLICATION supabase_realtime ADD TABLE public.packages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_settings;
