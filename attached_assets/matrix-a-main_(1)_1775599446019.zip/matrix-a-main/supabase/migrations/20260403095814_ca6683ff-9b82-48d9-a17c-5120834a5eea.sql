
CREATE TABLE public.app_admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  added_by text NOT NULL DEFAULT '',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.app_admins ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read admins" ON public.app_admins FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can insert admins" ON public.app_admins FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "Anyone can delete admins" ON public.app_admins FOR DELETE TO anon, authenticated USING (true);

-- Seed the default admin
INSERT INTO public.app_admins (email, added_by) VALUES ('seif83470@gmail.com', 'system');
