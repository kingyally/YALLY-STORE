
ALTER TABLE public.unlocked_tickets ADD COLUMN status text NOT NULL DEFAULT 'pending';

-- Allow updates so admin can approve/reject
CREATE POLICY "Anyone can update unlocked tickets" ON public.unlocked_tickets FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
