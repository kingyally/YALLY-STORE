DROP POLICY IF EXISTS "Service role can delete" ON public.app_users;
CREATE POLICY "Anyone can delete users" ON public.app_users FOR DELETE TO anon, authenticated USING (true);