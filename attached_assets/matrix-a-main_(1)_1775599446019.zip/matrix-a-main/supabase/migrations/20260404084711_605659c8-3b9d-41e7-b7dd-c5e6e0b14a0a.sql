
ALTER TABLE public.app_admins ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'admin';
ALTER TABLE public.app_admins ADD COLUMN IF NOT EXISTS permissions text[] NOT NULL DEFAULT ARRAY['requests']::text[];

UPDATE public.app_admins SET role = 'super_admin', permissions = ARRAY['users','requests','admins','tipsters','history','banners','packages','settings']::text[] WHERE email = 'seif83470@gmail.com';
