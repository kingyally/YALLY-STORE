
CREATE OR REPLACE FUNCTION public.hash_password(pw text)
RETURNS text
LANGUAGE sql
IMMUTABLE
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT extensions.crypt(pw, extensions.gen_salt('bf'));
$$;

CREATE OR REPLACE FUNCTION public.verify_password(pw text, pw_hash text)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
SECURITY DEFINER
SET search_path = public, extensions
AS $$
  SELECT pw_hash = extensions.crypt(pw, pw_hash);
$$;
