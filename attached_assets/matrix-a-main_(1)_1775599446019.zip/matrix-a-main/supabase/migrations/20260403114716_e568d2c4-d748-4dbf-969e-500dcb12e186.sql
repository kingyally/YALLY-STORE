
CREATE TABLE public.unlocked_tickets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.app_users(id) ON DELETE CASCADE,
  tipster_id INTEGER NOT NULL,
  unlocked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, tipster_id)
);

ALTER TABLE public.unlocked_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read unlocked tickets" ON public.unlocked_tickets
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Anyone can insert unlocked tickets" ON public.unlocked_tickets
  FOR INSERT TO anon, authenticated WITH CHECK (true);
