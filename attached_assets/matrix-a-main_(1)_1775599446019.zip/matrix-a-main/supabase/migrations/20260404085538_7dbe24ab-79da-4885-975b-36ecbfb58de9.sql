ALTER PUBLICATION supabase_realtime ADD TABLE public.unlocked_tickets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_admins;
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_users;