
-- Create banners table
CREATE TABLE public.banners (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_url text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.banners ENABLE ROW LEVEL SECURITY;

-- Everyone can read active banners
CREATE POLICY "Anyone can read banners" ON public.banners
  FOR SELECT TO anon, authenticated USING (true);

-- Anyone can insert banners (admin-only enforced in app)
CREATE POLICY "Anyone can insert banners" ON public.banners
  FOR INSERT TO anon, authenticated WITH CHECK (true);

-- Anyone can update banners
CREATE POLICY "Anyone can update banners" ON public.banners
  FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

-- Anyone can delete banners
CREATE POLICY "Anyone can delete banners" ON public.banners
  FOR DELETE TO anon, authenticated USING (true);

-- Insert default banners from the existing hero images
INSERT INTO public.banners (image_url, sort_order) VALUES
  ('default_hero_1', 0),
  ('default_hero_2', 1),
  ('default_hero_3', 2);

-- Create storage bucket for banner uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('banners', 'banners', true)
ON CONFLICT (id) DO NOTHING;

-- Allow public read access to banner files
CREATE POLICY "Public read access" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'banners');

-- Allow upload to banners bucket
CREATE POLICY "Allow banner uploads" ON storage.objects
  FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'banners');

-- Allow delete from banners bucket
CREATE POLICY "Allow banner deletes" ON storage.objects
  FOR DELETE TO anon, authenticated
  USING (bucket_id = 'banners');
