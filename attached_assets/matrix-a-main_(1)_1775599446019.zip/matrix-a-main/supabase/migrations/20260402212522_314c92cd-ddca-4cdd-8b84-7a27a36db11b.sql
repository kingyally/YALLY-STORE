
-- Create app_users table for Matrix Betting users
CREATE TABLE public.app_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT NOT NULL DEFAULT '',
  login_count INTEGER NOT NULL DEFAULT 1,
  last_login TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.app_users ENABLE ROW LEVEL SECURITY;

-- Anyone can register (insert)
CREATE POLICY "Anyone can register"
  ON public.app_users FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Anyone can read (for login check by phone)
CREATE POLICY "Anyone can read users"
  ON public.app_users FOR SELECT
  TO anon, authenticated
  USING (true);

-- Anyone can update their own login count (by phone match)
CREATE POLICY "Anyone can update login count"
  ON public.app_users FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Allow delete for admin purposes (via service role)
CREATE POLICY "Service role can delete"
  ON public.app_users FOR DELETE
  TO service_role
  USING (true);

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_app_users_updated_at
  BEFORE UPDATE ON public.app_users
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
