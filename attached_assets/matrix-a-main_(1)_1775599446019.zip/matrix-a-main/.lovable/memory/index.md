# Project Memory

## Core
Matrix Betting tips app. Dark theme, emerald (#10B981) primary. Inter font.
Mobile-first design, max-w-md centered. Lovable Cloud backend.
v4.0 - Premium glassmorphism UI, step-based payment flow, enhanced admin panel.

## Memories
- [Design tokens](mem://design/tokens) — Dark betting theme with emerald accents, glass effects, premium neon glows
