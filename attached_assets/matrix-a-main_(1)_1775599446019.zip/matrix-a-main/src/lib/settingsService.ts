import { supabase } from '@/integrations/supabase/client';
import { Tipster, History, Package } from '@/types/betting';

// ===================== TIPSTERS =====================

export const fetchTipsters = async (): Promise<Tipster[]> => {
  const { data, error } = await supabase
    .from('tipsters')
    .select('*')
    .order('id', { ascending: true });
  if (error) { console.error('fetchTipsters error:', error); return []; }
  return (data || []).map(row => ({
    id: row.id,
    name: row.name,
    category: row.category,
    odds: row.odds,
    company: row.company || '',
    avatar: row.avatar,
    code: row.code,
    isFree: row.is_free,
    expiryTime: row.expiry_time,
    expiryDate: row.expiry_date || undefined,
    prices: (row.prices as any) || [{ name: 'Siku 1', p: 2000, discount: 0 }],
  }));
};

export const upsertTipster = async (t: Tipster): Promise<boolean> => {
  const row = {
    id: t.id,
    name: t.name,
    category: t.category,
    odds: t.odds,
    company: t.company || '',
    avatar: t.avatar,
    code: t.code,
    is_free: t.isFree,
    expiry_time: t.expiryTime,
    expiry_date: t.expiryDate || null,
    prices: t.prices as any,
  };
  const { error } = await supabase.from('tipsters').upsert(row, { onConflict: 'id' });
  if (error) { console.error('upsertTipster error:', error); return false; }
  return true;
};

export const deleteTipsterFromDb = async (id: number): Promise<boolean> => {
  const { error } = await supabase.from('tipsters').delete().eq('id', id);
  if (error) { console.error('deleteTipster error:', error); return false; }
  return true;
};

// ===================== HISTORY =====================

export const fetchHistory = async (): Promise<History[]> => {
  const { data, error } = await supabase
    .from('bet_history')
    .select('*')
    .order('id', { ascending: false });
  if (error) { console.error('fetchHistory error:', error); return []; }
  return (data || []).map(row => ({
    id: row.id,
    title: row.title,
    date: row.date,
    result: row.result,
  }));
};

export const upsertHistory = async (h: History): Promise<boolean> => {
  const { error } = await supabase.from('bet_history').upsert(
    { id: h.id, title: h.title, date: h.date, result: h.result },
    { onConflict: 'id' }
  );
  if (error) { console.error('upsertHistory error:', error); return false; }
  return true;
};

export const deleteHistoryFromDb = async (id: number): Promise<boolean> => {
  const { error } = await supabase.from('bet_history').delete().eq('id', id);
  if (error) { console.error('deleteHistory error:', error); return false; }
  return true;
};

// ===================== PACKAGES =====================

export const fetchPackages = async (): Promise<Package[]> => {
  const { data, error } = await supabase
    .from('packages')
    .select('*')
    .order('id', { ascending: true });
  if (error) { console.error('fetchPackages error:', error); return []; }
  return (data || []).map(row => ({
    id: row.id,
    name: row.name,
    price: row.price,
    discount: row.discount || 0,
  }));
};

export const upsertPackage = async (p: Package): Promise<boolean> => {
  const { error } = await supabase.from('packages').upsert(
    { id: p.id, name: p.name, price: p.price, discount: p.discount || 0 },
    { onConflict: 'id' }
  );
  if (error) { console.error('upsertPackage error:', error); return false; }
  return true;
};

export const deletePackageFromDb = async (id: number): Promise<boolean> => {
  const { error } = await supabase.from('packages').delete().eq('id', id);
  if (error) { console.error('deletePackage error:', error); return false; }
  return true;
};

// ===================== APP SETTINGS =====================

export interface AppSettings {
  id?: string;
  telegramChannel: string;
  whatsappGroup: string;
  whatsappNumber: string;
  supportEmail: string;
  paymentNumber: string;
  paymentMethods: string[];
}

export const fetchAppSettings = async (): Promise<AppSettings | null> => {
  const { data, error } = await supabase
    .from('app_settings')
    .select('*')
    .limit(1)
    .single();
  if (error || !data) return null;
  return {
    id: data.id,
    telegramChannel: data.telegram_channel || '',
    whatsappGroup: data.whatsapp_group || '',
    whatsappNumber: data.whatsapp_number || '',
    supportEmail: data.support_email || '',
    paymentNumber: data.payment_number || '',
    paymentMethods: data.payment_methods || [],
  };
};

export const updateAppSettings = async (s: AppSettings): Promise<boolean> => {
  const { error } = await supabase
    .from('app_settings')
    .update({
      telegram_channel: s.telegramChannel,
      whatsapp_group: s.whatsappGroup,
      whatsapp_number: s.whatsappNumber,
      support_email: s.supportEmail,
      payment_number: s.paymentNumber,
      payment_methods: s.paymentMethods,
    })
    .eq('id', s.id!);
  if (error) { console.error('updateAppSettings error:', error); return false; }
  return true;
};
