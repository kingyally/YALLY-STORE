import { supabase } from '@/integrations/supabase/client';

export type AdminRole = 'super_admin' | 'admin';

export const ALL_PERMISSIONS = ['dashboard', 'users', 'requests', 'admins', 'tipsters', 'history', 'banners', 'packages', 'settings'] as const;
export type AdminPermission = typeof ALL_PERMISSIONS[number];

export const PERMISSION_LABELS: Record<AdminPermission, string> = {
  dashboard: 'Dashboard',
  users: 'Watumiaji',
  requests: 'Maombi',
  admins: 'Admins',
  tipsters: 'Tipsters',
  history: 'Historia',
  banners: 'Banners',
  packages: 'Packages',
  settings: 'Settings',
};

export interface AdminEntry {
  id: string;
  email: string;
  added_by: string;
  created_at: string;
  role: AdminRole;
  permissions: AdminPermission[];
}

export async function fetchAdmins(): Promise<AdminEntry[]> {
  const { data, error } = await supabase
    .from('app_admins')
    .select('*')
    .order('created_at', { ascending: true });

  if (error) {
    console.error('Error fetching admins:', error);
    return [];
  }
  return (data || []) as AdminEntry[];
}

export async function getAdminEntry(email: string): Promise<AdminEntry | null> {
  const { data } = await supabase
    .from('app_admins')
    .select('*')
    .eq('email', email.toLowerCase())
    .maybeSingle();
  return data as AdminEntry | null;
}

export async function isAdmin(email: string): Promise<boolean> {
  const { data } = await supabase
    .from('app_admins')
    .select('id')
    .eq('email', email.toLowerCase())
    .maybeSingle();
  return !!data;
}

export async function addAdmin(email: string, addedBy: string, permissions: AdminPermission[] = ['requests']): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase
    .from('app_admins')
    .insert({ email: email.toLowerCase(), added_by: addedBy, role: 'admin', permissions });

  if (error) {
    if (error.code === '23505') return { success: false, error: 'Email hii ipo tayari!' };
    console.error('Error adding admin:', error);
    return { success: false, error: 'Kuna tatizo.' };
  }
  return { success: true };
}

export async function updateAdminPermissions(adminId: string, permissions: AdminPermission[]): Promise<boolean> {
  const { error } = await supabase
    .from('app_admins')
    .update({ permissions })
    .eq('id', adminId);

  if (error) {
    console.error('Error updating permissions:', error);
    return false;
  }
  return true;
}

export async function removeAdmin(adminId: string): Promise<boolean> {
  const { error } = await supabase
    .from('app_admins')
    .delete()
    .eq('id', adminId);

  if (error) {
    console.error('Error removing admin:', error);
    return false;
  }
  return true;
}
