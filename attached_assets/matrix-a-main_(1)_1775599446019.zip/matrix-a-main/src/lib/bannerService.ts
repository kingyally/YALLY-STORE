import { supabase } from '@/integrations/supabase/client';

export interface Banner {
  id: string;
  image_url: string;
  sort_order: number;
  active: boolean;
  created_at: string;
}

export async function fetchBanners(): Promise<Banner[]> {
  const { data, error } = await supabase
    .from('banners')
    .select('*')
    .order('sort_order', { ascending: true });
  if (error) { console.error('fetchBanners error:', error); return []; }
  return (data || []) as Banner[];
}

export async function fetchActiveBannerUrls(): Promise<string[]> {
  const banners = await fetchBanners();
  const active = banners.filter(b => b.active);
  return active.map(b => {
    if (b.image_url.startsWith('http')) return b.image_url;
    // It's a storage path
    const { data } = supabase.storage.from('banners').getPublicUrl(b.image_url);
    return data.publicUrl;
  });
}

export async function uploadBannerImage(file: File): Promise<string | null> {
  const ext = file.name.split('.').pop();
  const path = `${Date.now()}_${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await supabase.storage.from('banners').upload(path, file);
  if (error) { console.error('Upload error:', error); return null; }
  return path;
}

export async function addBanner(imageUrl: string, sortOrder: number): Promise<Banner | null> {
  const { data, error } = await supabase
    .from('banners')
    .insert({ image_url: imageUrl, sort_order: sortOrder })
    .select()
    .single();
  if (error) { console.error('addBanner error:', error); return null; }
  return data as Banner;
}

export async function updateBanner(id: string, updates: Partial<Pick<Banner, 'image_url' | 'sort_order' | 'active'>>): Promise<boolean> {
  const { error } = await supabase.from('banners').update(updates).eq('id', id);
  if (error) { console.error('updateBanner error:', error); return false; }
  return true;
}

export async function deleteBanner(id: string, storagePath?: string): Promise<boolean> {
  if (storagePath && !storagePath.startsWith('http') && !storagePath.startsWith('default_')) {
    await supabase.storage.from('banners').remove([storagePath]);
  }
  const { error } = await supabase.from('banners').delete().eq('id', id);
  if (error) { console.error('deleteBanner error:', error); return false; }
  return true;
}
