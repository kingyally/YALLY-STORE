import { supabase } from '@/integrations/supabase/client';

// Validate Tanzanian phone number (07xx, 06xx, 255xxx)
export function isValidTanzanianPhone(phone: string): boolean {
  const cleaned = phone.replace(/[\s\-()]/g, '');
  // Accepts: 07xxxxxxxx, 06xxxxxxxx, 2557xxxxxxxx, 2556xxxxxxxx, +2557xxxxxxxx, +2556xxxxxxxx
  return /^(\+?255|0)[67]\d{8}$/.test(cleaned);
}

// Validate email format
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

// Normalize phone to 07/06 format
export function normalizePhone(phone: string): string {
  const cleaned = phone.replace(/[\s\-()]/g, '');
  if (cleaned.startsWith('+255')) return '0' + cleaned.slice(4);
  if (cleaned.startsWith('255')) return '0' + cleaned.slice(3);
  return cleaned;
}

export interface AppUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  login_count: number;
  last_login: string;
  created_at: string;
}

const SESSION_KEY = 'matrix_session';

export function saveSession(user: AppUser) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(user));
}

export function loadSession(): AppUser | null {
  try {
    const data = localStorage.getItem(SESSION_KEY);
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

// Login existing user with phone + password
export async function loginUser(phone: string, password: string): Promise<{ user: AppUser | null; error?: string }> {
  const normalizedPhone = normalizePhone(phone);
  
  const { data: existing } = await supabase
    .from('app_users')
    .select('*')
    .eq('phone', normalizedPhone)
    .maybeSingle();

  if (!existing) {
    return { user: null, error: 'Namba hii haipo. Jisajili kwanza!' };
  }

  const existingHash = (existing as any).password_hash;

  if (!existingHash) {
    const { data: hashedPw } = await supabase.rpc('hash_password', { pw: password });
    await supabase
      .from('app_users')
      .update({ password_hash: hashedPw } as any)
      .eq('id', existing.id);
  } else {
    const { data: isValid } = await supabase.rpc('verify_password', {
      pw: password,
      pw_hash: existingHash,
    });
    if (!isValid) {
      return { user: null, error: 'Password si sahihi!' };
    }
  }

  await supabase
    .from('app_users')
    .update({
      login_count: (existing.login_count || 0) + 1,
      last_login: new Date().toISOString(),
    })
    .eq('id', existing.id);

  const user = { ...existing, login_count: (existing.login_count || 0) + 1 } as AppUser;
  saveSession(user);
  return { user };
}

// Register new user
export async function registerUser(name: string, phone: string, email: string, password: string): Promise<{ user: AppUser | null; error?: string }> {
  // Validate phone
  if (!isValidTanzanianPhone(phone)) {
    return { user: null, error: 'Namba ya simu si sahihi. Tumia namba ya Tanzania (07xx au 06xx).' };
  }
  
  // Validate email
  if (!isValidEmail(email)) {
    return { user: null, error: 'Email si sahihi. Tafadhali weka email halisi.' };
  }

  // Validate password length
  if (password.length < 4) {
    return { user: null, error: 'Password lazima iwe na angalau herufi 4.' };
  }

  // Validate name
  if (name.trim().length < 2) {
    return { user: null, error: 'Tafadhali weka jina lako kamili.' };
  }

  const normalizedPhone = normalizePhone(phone);

  const { data: existing } = await supabase
    .from('app_users')
    .select('id')
    .eq('phone', normalizedPhone)
    .maybeSingle();

  if (existing) {
    return { user: null, error: 'Namba hii ipo tayari. Ingia tu!' };
  }

  // Check email uniqueness
  const { data: emailExists } = await supabase
    .from('app_users')
    .select('id')
    .eq('email', email.trim().toLowerCase())
    .maybeSingle();

  if (emailExists) {
    return { user: null, error: 'Email hii ipo tayari. Tumia email nyingine.' };
  }

  const { data: hashedPw } = await supabase.rpc('hash_password', { pw: password });

  const { data: newUser, error } = await supabase
    .from('app_users')
    .insert({
      name: name.trim(),
      phone: normalizedPhone,
      email: email.trim().toLowerCase(),
      password_hash: hashedPw,
      login_count: 1,
      last_login: new Date().toISOString(),
    })
    .select()
    .single();

  if (error) {
    console.error('Registration error:', error);
    return { user: null, error: 'Kuna tatizo la usajili.' };
  }

  const user = newUser as AppUser;
  saveSession(user);
  return { user };
}

// Unlocked tickets
export async function saveUnlockedTicket(userId: string, tipsterId: number): Promise<boolean> {
  const { error } = await supabase
    .from('unlocked_tickets')
    .upsert({ user_id: userId, tipster_id: tipsterId, status: 'approved' } as any, { onConflict: 'user_id,tipster_id' });

  if (error) {
    console.error('Error saving unlocked ticket:', error);
    return false;
  }
  return true;
}

export async function loadUnlockedTickets(userId: string): Promise<number[]> {
  const { data, error } = await (supabase
    .from('unlocked_tickets')
    .select('tipster_id')
    .eq('user_id', userId) as any)
    .eq('status', 'approved');

  if (error) {
    console.error('Error loading unlocked tickets:', error);
    return [];
  }

  return (data || []).map(row => row.tipster_id);
}


export interface TicketRequest {
  id: string;
  user_id: string;
  tipster_id: number;
  status: string;
  unlocked_at: string;
  user_name?: string;
  user_phone?: string;
}

export async function fetchAllTicketRequests(): Promise<TicketRequest[]> {
  const { data, error } = await supabase
    .from('unlocked_tickets')
    .select('*')
    .order('unlocked_at', { ascending: false });

  if (error) {
    console.error('Error fetching ticket requests:', error);
    return [];
  }

  const requests = (data || []) as any[];
  
  // Fetch user info for each request
  const userIds = [...new Set(requests.map(r => r.user_id))];
  const { data: users } = await supabase
    .from('app_users')
    .select('id, name, phone')
    .in('id', userIds);

  const userMap = new Map((users || []).map(u => [u.id, u]));

  return requests.map(r => ({
    ...r,
    user_name: userMap.get(r.user_id)?.name || 'Unknown',
    user_phone: userMap.get(r.user_id)?.phone || '',
  }));
}

export async function updateTicketStatus(ticketId: string, status: 'approved' | 'rejected'): Promise<boolean> {
  const { error } = await supabase
    .from('unlocked_tickets')
    .update({ status } as any)
    .eq('id', ticketId);

  if (error) {
    console.error('Error updating ticket status:', error);
    return false;
  }
  return true;
}

export async function fetchAllUsers(): Promise<AppUser[]> {
  const { data, error } = await supabase
    .from('app_users')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching users:', error);
    return [];
  }

  return (data || []) as AppUser[];
}

export async function deleteUser(userId: string): Promise<boolean> {
  const { error } = await supabase
    .from('app_users')
    .delete()
    .eq('id', userId);

  if (error) {
    console.error('Error deleting user:', error);
    return false;
  }
  return true;
}
