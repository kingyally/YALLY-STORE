import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Phone, Shield, CheckCircle, Check, ArrowRight, AlertCircle, Smartphone, Loader2, XCircle } from 'lucide-react';
import { Tipster } from '@/types/betting';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface PaymentModalProps {
  tipster: Tipster;
  onClose: () => void;
  onSuccess: (tipsterId: number) => void;
  paymentNumber: string;
  paymentMethods: string[];
  userId?: string;
  userName?: string;
  userEmail?: string;
  userPhone?: string;
}

type PaymentStatus = 'idle' | 'sending' | 'waiting' | 'success' | 'failed' | 'cancelled';

export const PaymentModal: React.FC<PaymentModalProps> = ({
  tipster, onClose, onSuccess, paymentMethods, userId, userName, userEmail, userPhone
}) => {
  const [phone, setPhone] = useState(userPhone || '');
  const [selectedMethod, setSelectedMethod] = useState(paymentMethods[0] || 'M-PESA');
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('idle');
  const [orderId, setOrderId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [pollCount, setPollCount] = useState(0);

  const price = tipster.prices?.[0];
  const finalPrice = price ? price.p - (price.discount || 0) : 0;

  // Poll for payment status
  const checkPaymentStatus = useCallback(async () => {
    if (!orderId || paymentStatus !== 'waiting') return;

    try {
      const { data, error } = await supabase.functions.invoke('sonicpesa-payment', {
        body: {
          action: 'check_status',
          order_id: orderId,
          user_id: userId,
          tipster_id: tipster.id,
        },
      });

      if (error) {
        console.error('Status check error:', error);
        return;
      }

      const status = data?.status;
      console.log('Payment status:', status);

      if (status === 'SUCCESS') {
        setPaymentStatus('success');
        setStep(3);
        toast.success('Malipo yamefanikiwa! 🎉');
        setTimeout(() => onSuccess(tipster.id), 2500);
      } else if (status === 'CANCELLED' || status === 'USERCANCELLED') {
        setPaymentStatus('cancelled');
        setErrorMessage('Malipo yameghairiwa. Jaribu tena.');
      } else if (status === 'REJECTED') {
        setPaymentStatus('failed');
        setErrorMessage('Malipo yamekataliwa. Hakikisha una salio la kutosha.');
      }
      // PENDING / INPROGRESS → keep polling
    } catch (err) {
      console.error('Status poll error:', err);
    }
  }, [orderId, paymentStatus, userId, tipster.id, onSuccess]);

  // Polling effect
  useEffect(() => {
    if (paymentStatus !== 'waiting' || !orderId) return;

    const interval = setInterval(() => {
      setPollCount(prev => {
      if (prev >= 200) { // ~10 minutes (200 * 3s = 600s)
          setPaymentStatus('failed');
          setErrorMessage('Muda wa kusubiri umekwisha (dakika 10). Jaribu tena.');
          // Auto-cleanup the paying record
          if (userId && tipster.id) {
            supabase
              .from('unlocked_tickets')
              .delete()
              .eq('user_id', userId)
              .eq('tipster_id', tipster.id)
              .eq('status', 'pending');
          }
          return prev;
        }
        checkPaymentStatus();
        return prev + 1;
      });
    }, 3000);

    return () => clearInterval(interval);
  }, [paymentStatus, orderId, checkPaymentStatus]);

  const handlePay = async () => {
    if (!phone.trim()) {
      toast.error('Weka namba ya simu!');
      return;
    }

    setPaymentStatus('sending');
    setErrorMessage('');
    setPollCount(0);

    try {
      const { data, error } = await supabase.functions.invoke('sonicpesa-payment', {
        body: {
          action: 'create_order',
          buyer_name: userName || 'Customer',
          buyer_email: userEmail || '',
          buyer_phone: phone.trim(),
          amount: finalPrice,
          user_id: userId,
          tipster_id: tipster.id,
        },
      });

      if (error) {
        console.error('Payment creation error:', error);
        setPaymentStatus('failed');
        setErrorMessage('Imeshindwa kutuma ombi la malipo. Jaribu tena.');
        return;
      }

      if (data?.data?.order_id) {
        setOrderId(data.data.order_id);
        setPaymentStatus('waiting');
        toast.info('USSD imetumwa kwenye simu yako! Thibitisha malipo.');
      } else {
        setPaymentStatus('failed');
        setErrorMessage('Jibu la SonicPesa halikuwa sahihi. Jaribu tena.');
      }
    } catch (err) {
      console.error('Payment error:', err);
      setPaymentStatus('failed');
      setErrorMessage('Kuna tatizo la mtandao. Jaribu tena.');
    }
  };

  // Clean up the "paying" record from DB when payment fails
  const cleanupPayingRecord = useCallback(async () => {
    if (!userId || !tipster.id) return;
    try {
      await supabase
        .from('unlocked_tickets')
        .delete()
        .eq('user_id', userId)
        .eq('tipster_id', tipster.id)
        .eq('status', 'pending');
    } catch (err) {
      console.error('Failed to cleanup paying record:', err);
    }
  }, [userId, tipster.id]);

  const handleRetry = async () => {
    await cleanupPayingRecord();
    setPaymentStatus('idle');
    setErrorMessage('');
    setOrderId(null);
    setPollCount(0);
  };

  const getMethodColor = (method: string) => {
    switch (method) {
      case 'M-PESA': return 'border-red-500/30 bg-red-500/8 text-red-400';
      case 'TIGO PESA': return 'border-blue-500/30 bg-blue-500/8 text-blue-400';
      case 'AIRTEL MONEY': return 'border-rose-500/30 bg-rose-500/8 text-rose-400';
      case 'HALOPESA': return 'border-amber-500/30 bg-amber-500/8 text-amber-400';
      default: return 'border-primary/30 bg-primary/8 text-primary';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-background/85 backdrop-blur-xl"
        onClick={paymentStatus === 'waiting' ? undefined : () => { if (paymentStatus !== 'success') cleanupPayingRecord(); onClose(); }}
      />
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="relative w-full max-w-sm glass-strong rounded-t-3xl sm:rounded-3xl p-6 space-y-4 noise-texture"
      >
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-10 h-1 rounded-full bg-muted-foreground/15 sm:hidden" />

        <div className="flex justify-between items-center pt-1">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-primary/10 border border-primary/20">
              <Shield size={16} className="text-primary" />
            </div>
            <div>
              <h2 className="text-base font-black uppercase tracking-tight font-display">Lipia Tip</h2>
              <p className="text-[8px] text-muted-foreground uppercase tracking-widest">SonicPesa • Malipo Salama</p>
            </div>
          </div>
          {paymentStatus !== 'waiting' && (
            <button onClick={onClose} className="p-2 rounded-lg glass-subtle hover:bg-secondary/50 transition-colors">
              <X size={16} className="text-muted-foreground" />
            </button>
          )}
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-2">
          {[1, 2, 3].map(s => (
            <React.Fragment key={s}>
              <div className={`flex items-center justify-center w-7 h-7 rounded-full text-[10px] font-black transition-all ${
                step >= s
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground'
              }`}>
                {step > s ? <Check size={12} /> : s}
              </div>
              {s < 3 && <div className={`flex-1 h-0.5 rounded-full transition-all ${step > s ? 'bg-primary' : 'bg-border'}`} />}
            </React.Fragment>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 1: Select method & see info */}
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              <div className="flex items-center gap-3 p-3.5 glass-subtle rounded-xl">
                <img src={tipster.avatar} alt={tipster.name} className="w-12 h-12 rounded-xl object-cover ring-2 ring-border/30" referrerPolicy="no-referrer" />
                <div className="flex-1">
                  <p className="text-sm font-bold font-display">{tipster.name}</p>
                  <p className="text-[9px] text-muted-foreground/50 font-bold uppercase tracking-widest">{tipster.category}</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black text-primary font-display">
                    TSH {finalPrice.toLocaleString()}
                  </p>
                  {price?.discount ? (
                    <p className="text-[9px] text-muted-foreground line-through">TSH {price.p.toLocaleString()}</p>
                  ) : null}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[9px] font-black text-muted-foreground/50 uppercase tracking-[0.2em]">Chagua Njia ya Malipo</label>
                <div className="grid grid-cols-2 gap-2">
                  {paymentMethods.map(method => (
                    <button
                      key={method}
                      onClick={() => setSelectedMethod(method)}
                      className={`py-3 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all duration-300 border ${
                        selectedMethod === method
                          ? `${getMethodColor(method)} ring-1 ring-current/20`
                          : 'border-border/20 bg-secondary/30 text-muted-foreground/50 hover:text-muted-foreground'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={() => setStep(2)}
                className="w-full py-3.5 btn-primary-premium text-primary-foreground font-black rounded-xl text-[11px] uppercase tracking-widest flex items-center justify-center gap-2"
              >
                Endelea <ArrowRight size={14} />
              </motion.button>
            </motion.div>
          )}

          {/* Step 2: Enter phone & pay */}
          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-4">
              {/* How it works */}
              <div className="glass-subtle rounded-xl p-4 space-y-3 border-primary/10">
                <div className="flex items-center gap-2 mb-2">
                  <Smartphone size={14} className="text-primary" />
                  <h3 className="text-[11px] font-black uppercase tracking-wider">Jinsi Inavyofanya Kazi</h3>
                </div>
                <div className="space-y-2">
                  {[
                    'Weka namba ya simu yako hapa chini',
                    `SonicPesa itatuma USSD prompt kwenye simu yako`,
                    `Thibitisha malipo ya TSH ${finalPrice.toLocaleString()} kwa PIN yako`,
                    'Tip itafunguliwa moja kwa moja baada ya malipo!',
                  ].map((instruction, i) => (
                    <div key={i} className="flex items-start gap-2.5">
                      <span className="flex-shrink-0 w-5 h-5 rounded-full bg-primary/15 text-primary text-[9px] font-black flex items-center justify-center">
                        {i + 1}
                      </span>
                      <p className="text-[10px] text-foreground/80 leading-relaxed pt-0.5">{instruction}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Amount */}
              <div className="text-center py-2">
                <span className="text-[9px] text-muted-foreground uppercase tracking-widest">Kiasi cha kulipa</span>
                <p className="text-2xl font-black text-primary font-display">TSH {finalPrice.toLocaleString()}</p>
                <p className="text-[9px] text-muted-foreground mt-1">{selectedMethod}</p>
              </div>

              {/* Phone input */}
              <div className="space-y-2">
                <label className="text-[9px] font-black text-muted-foreground/50 uppercase tracking-[0.2em]">Namba ya Simu ({selectedMethod})</label>
                <div className="relative">
                  <Phone size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground/40" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="07xxxxxxxx"
                    disabled={paymentStatus === 'waiting' || paymentStatus === 'sending'}
                    className="w-full glass-subtle border-border/30 rounded-xl pl-11 pr-4 py-3.5 text-foreground placeholder:text-muted-foreground/30 focus:border-primary/50 outline-none transition-all text-sm font-medium disabled:opacity-50"
                  />
                </div>
              </div>

              {/* Payment status messages */}
              {paymentStatus === 'waiting' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-3 p-3.5 rounded-xl bg-primary/10 border border-primary/20"
                >
                  <Loader2 size={18} className="text-primary animate-spin flex-shrink-0" />
                  <div>
                    <p className="text-[11px] font-bold text-primary">Inasubiri uthibitisho...</p>
                    <p className="text-[9px] text-muted-foreground">Angalia simu yako na uthibitishe kwa PIN</p>
                  </div>
                </motion.div>
              )}

              {(paymentStatus === 'failed' || paymentStatus === 'cancelled') && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-destructive/10 border border-destructive/20"
                >
                  <XCircle size={16} className="text-destructive mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-[11px] font-bold text-destructive">
                      {paymentStatus === 'cancelled' ? 'Imeghairiwa' : 'Imeshindwa'}
                    </p>
                    <p className="text-[9px] text-muted-foreground">{errorMessage}</p>
                  </div>
                </motion.div>
              )}

              {/* Action buttons */}
              <div className="flex gap-2">
                {paymentStatus !== 'waiting' && (
                  <button
                    onClick={() => { setStep(1); handleRetry(); }}
                    className="px-4 py-3.5 glass-subtle rounded-xl text-[10px] font-black text-muted-foreground uppercase tracking-wider"
                  >
                    Rudi
                  </button>
                )}

                {(paymentStatus === 'idle' || paymentStatus === 'failed' || paymentStatus === 'cancelled') && (
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    onClick={paymentStatus === 'idle' ? handlePay : handleRetry}
                    disabled={!phone.trim()}
                    className="flex-1 py-3.5 btn-primary-premium text-primary-foreground font-black rounded-xl text-[11px] uppercase tracking-widest disabled:opacity-20 transition-all flex items-center justify-center gap-2"
                  >
                    {paymentStatus === 'idle' ? (
                      <>
                        <Smartphone size={15} />
                        Lipa Sasa
                      </>
                    ) : (
                      <>
                        <ArrowRight size={15} />
                        Jaribu Tena
                      </>
                    )}
                  </motion.button>
                )}

                {paymentStatus === 'sending' && (
                  <div className="flex-1 py-3.5 glass-subtle rounded-xl flex items-center justify-center gap-2">
                    <Loader2 size={16} className="text-primary animate-spin" />
                    <span className="text-[11px] font-bold text-muted-foreground">Inatuma...</span>
                  </div>
                )}
              </div>

              <div className="flex items-start gap-2 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/10">
                <AlertCircle size={12} className="text-amber-400 mt-0.5 flex-shrink-0" />
                <p className="text-[9px] text-amber-400/70">
                  USSD prompt itatumwa kwenye simu yako. Thibitisha kwa PIN yako ya {selectedMethod}.
                </p>
              </div>
            </motion.div>
          )}

          {/* Step 3: Success */}
          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="py-8 text-center space-y-4">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', delay: 0.2 }}
                className="w-20 h-20 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center mx-auto animate-glow-pulse"
              >
                <CheckCircle size={40} className="text-primary" />
              </motion.div>
              <div>
                <h3 className="text-lg font-black uppercase font-display">Malipo Yamefanikiwa!</h3>
                <p className="text-[11px] text-muted-foreground mt-1.5">Tip imefunguliwa. Furahia!</p>
              </div>
              <div className="text-[9px] text-muted-foreground/50">Inaelekeza...</div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
