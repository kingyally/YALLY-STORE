export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_admins: {
        Row: {
          added_by: string
          created_at: string
          email: string
          id: string
          permissions: string[]
          role: string
        }
        Insert: {
          added_by?: string
          created_at?: string
          email: string
          id?: string
          permissions?: string[]
          role?: string
        }
        Update: {
          added_by?: string
          created_at?: string
          email?: string
          id?: string
          permissions?: string[]
          role?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          id: string
          payment_methods: string[] | null
          payment_number: string | null
          support_email: string | null
          telegram_channel: string | null
          updated_at: string
          whatsapp_group: string | null
          whatsapp_number: string | null
        }
        Insert: {
          id?: string
          payment_methods?: string[] | null
          payment_number?: string | null
          support_email?: string | null
          telegram_channel?: string | null
          updated_at?: string
          whatsapp_group?: string | null
          whatsapp_number?: string | null
        }
        Update: {
          id?: string
          payment_methods?: string[] | null
          payment_number?: string | null
          support_email?: string | null
          telegram_channel?: string | null
          updated_at?: string
          whatsapp_group?: string | null
          whatsapp_number?: string | null
        }
        Relationships: []
      }
      app_users: {
        Row: {
          created_at: string
          email: string
          id: string
          last_login: string
          login_count: number
          name: string
          password_hash: string
          phone: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string
          id?: string
          last_login?: string
          login_count?: number
          name: string
          password_hash?: string
          phone: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          last_login?: string
          login_count?: number
          name?: string
          password_hash?: string
          phone?: string
          updated_at?: string
        }
        Relationships: []
      }
      banners: {
        Row: {
          active: boolean
          created_at: string
          id: string
          image_url: string
          sort_order: number
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          image_url: string
          sort_order?: number
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          image_url?: string
          sort_order?: number
        }
        Relationships: []
      }
      bet_history: {
        Row: {
          created_at: string
          date: string
          id: number
          result: string
          title: string
        }
        Insert: {
          created_at?: string
          date?: string
          id?: number
          result?: string
          title?: string
        }
        Update: {
          created_at?: string
          date?: string
          id?: number
          result?: string
          title?: string
        }
        Relationships: []
      }
      packages: {
        Row: {
          created_at: string
          discount: number | null
          id: number
          name: string
          price: number
        }
        Insert: {
          created_at?: string
          discount?: number | null
          id?: number
          name?: string
          price?: number
        }
        Update: {
          created_at?: string
          discount?: number | null
          id?: number
          name?: string
          price?: number
        }
        Relationships: []
      }
      tipsters: {
        Row: {
          avatar: string
          category: string
          code: string
          company: string | null
          created_at: string
          expiry_date: string | null
          expiry_time: number
          id: number
          is_free: boolean
          name: string
          odds: string
          prices: Json | null
        }
        Insert: {
          avatar?: string
          category?: string
          code?: string
          company?: string | null
          created_at?: string
          expiry_date?: string | null
          expiry_time?: number
          id?: number
          is_free?: boolean
          name: string
          odds?: string
          prices?: Json | null
        }
        Update: {
          avatar?: string
          category?: string
          code?: string
          company?: string | null
          created_at?: string
          expiry_date?: string | null
          expiry_time?: number
          id?: number
          is_free?: boolean
          name?: string
          odds?: string
          prices?: Json | null
        }
        Relationships: []
      }
      unlocked_tickets: {
        Row: {
          id: string
          status: string
          tipster_id: number
          unlocked_at: string
          user_id: string
        }
        Insert: {
          id?: string
          status?: string
          tipster_id: number
          unlocked_at?: string
          user_id: string
        }
        Update: {
          id?: string
          status?: string
          tipster_id?: number
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "unlocked_tickets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "app_users"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      hash_password: { Args: { pw: string }; Returns: string }
      verify_password: {
        Args: { pw: string; pw_hash: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
